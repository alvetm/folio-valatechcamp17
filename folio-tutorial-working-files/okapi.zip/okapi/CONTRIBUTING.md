# Contribution guidelines

Guidelines for Contributing Code:
[dev.folio.org/community/contrib-code](http://dev.folio.org/community/contrib-code)
