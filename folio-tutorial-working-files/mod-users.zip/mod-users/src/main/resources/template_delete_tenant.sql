DROP SCHEMA IF EXISTS myuniversity_mymodule CASCADE;

DROP ROLE IF EXISTS myuniversity_mymodule;
