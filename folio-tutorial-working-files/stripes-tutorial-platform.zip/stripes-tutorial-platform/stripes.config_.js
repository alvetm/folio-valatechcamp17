module.exports = {
  okapi: {},
  config: { disableAuth: true, hasAllPerms: true },
  modules: {
    '@folio/trivial': {}
  }
};
